// ============================================================
// GERADOR_TONY - Servidor Backend Node.js
// Acesso exclusivo do dono (Tony)
// ============================================================

const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ====== CREDENCIAIS EXCLUSIVAS DO DONO ======
// ALTERE AQUI se quiser mudar a senha do dono
const OWNER_CREDENTIALS = {
  username: 'tony',
  password: 'tony123'
};
// ============================================

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({
  secret: 'gerador_tony_super_secret_key_2026',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 4, // 4 horas
    httpOnly: true
  }
}));

// Middleware para proteger rotas
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) {
    return next();
  }
  return res.redirect('/login');
}

// ====== ROTAS ======

// Página inicial -> redireciona
app.get('/', (req, res) => {
  if (req.session && req.session.authenticated) {
    return res.redirect('/app');
  }
  res.redirect('/login');
});

// Página de login
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Processar login
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (
    username === OWNER_CREDENTIALS.username &&
    password === OWNER_CREDENTIALS.password
  ) {
    req.session.authenticated = true;
    req.session.user = username;
    return res.json({ success: true, redirect: '/app' });
  }

  return res.status(401).json({
    success: false,
    message: 'Usuário ou senha incorretos. Acesso negado.'
  });
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

// App principal (PROTEGIDO)
app.get('/app', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'app.html'));
});

// API: gerar imagem (PROTEGIDA)
app.post('/api/generate', requireAuth, (req, res) => {
  const { prompt, width, height, model, seed } = req.body;

  if (!prompt || prompt.trim().length === 0) {
    return res.status(400).json({ error: 'Prompt vazio' });
  }

  // Sanitiza o prompt para URL
  const encodedPrompt = encodeURIComponent(prompt.trim());
  const w = parseInt(width) || 1024;
  const h = parseInt(height) || 1024;
  const m = model || 'flux';
  const s = seed || Math.floor(Math.random() * 1000000);

  // Pollinations.ai - API gratuita, sem chave necessária
  const imageUrl =
    `https://image.pollinations.ai/prompt/${encodedPrompt}` +
    `?width=${w}&height=${h}&model=${m}&seed=${s}&nologo=true&enhance=true`;

  res.json({
    success: true,
    imageUrl,
    prompt,
    width: w,
    height: h,
    model: m,
    seed: s
  });
});

// Verificar sessão
app.get('/api/status', (req, res) => {
  res.json({
    authenticated: !!(req.session && req.session.authenticated),
    user: req.session?.user || null
  });
});

// Arquivos estáticos (CSS/JS públicos, mas SEM as páginas protegidas)
app.use('/static', express.static(path.join(__dirname, 'public', 'static')));

app.listen(PORT, () => {
  console.log('============================================');
  console.log('   GERADOR_TONY rodando em http://localhost:' + PORT);
  console.log('   Login exclusivo do dono Tony');
  console.log('============================================');
});
